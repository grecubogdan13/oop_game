public class Finish implements CellElement{
    public char toCharacter() {
        return 'F';
    }
}
