public interface CellElement {
    public char toCharacter();
}
