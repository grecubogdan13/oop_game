public class Ice extends Spell{
    public Ice(int mc,int dam){
        setManaCost(mc);
        setDamage(dam);
    }
}
