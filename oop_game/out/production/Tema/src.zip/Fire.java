public class Fire extends Spell {
    public Fire(int mc,int dam){
        setManaCost(mc);
        setDamage(dam);
    }
}
