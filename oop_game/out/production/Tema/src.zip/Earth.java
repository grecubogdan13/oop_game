public class Earth extends Spell{
    public Earth(int mc,int dam){
        setManaCost(mc);
        setDamage(dam);
    }
}
