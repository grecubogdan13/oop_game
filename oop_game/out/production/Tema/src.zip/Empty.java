public class Empty implements CellElement{
    public char toCharacter() {
        return 'N';
    }
}
