public interface Potion {
    public void usePotion(Character c);
    public int getPrice();
    public int getValue();
    public int getWeight();
}
